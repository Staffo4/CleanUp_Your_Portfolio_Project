<template lang="">

    <nav class="navbar navbar-expand-sm navbar-light bg-light">
        <div class="container-fluid">
            <a class="navbar-brand" href="#">AutoGeekNation</a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarID"
                aria-controls="navbarID" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarID">
                <div class="navbar-nav">
                    <a class="nav-link active" aria-current="page" href="#">Home</a>
                    
                </div>
                 <div class="navbar-nav">
                    <a class="nav-link" aria-current="page" href="#">Blog</a>
                    
                </div>
                 <div class="navbar-nav">
                    <a class="nav-link" aria-current="page" href="#">Contact</a>
                    
                </div>
            </div>
        </div>
    </nav>
    
</template>


<script>
export default {};
</script>


<style lang="">
</style>